create database ProyectoC

CREATE TABLE usuarios (
  usuario varchar(30) primary key,
  contrase�a numeric(30)  NOT NULL,
  nombre Varchar(50) NOT NULL,
  apellido Varchar(50) NOT NULL,
  Puesto Varchar(50) NOT NULL,
  sexo Varchar(50)NOT NULL,
) 


CREATE TABLE proveedor (
  codigoprove numeric (10 )primary key,
  nombreprove varchar(50) NOT NULL,
  telprove numeric (10) NOT NULL,
  correoprove varchar (50) NOT NULL,
 ) 


CREATE TABLE productos (
   codprod numeric (30 )primary key,
   descprod varchar(30) NOT NULL,
   cantprod numeric (30) NOT NULL,
   precioprod numeric (30) NOT NULL
) 

CREATE TABLE Orden_Compra(
Nocom Varchar(40)Primary Key,
NoPro Varchar(50)NOT NULL,
Direccion Varchar(50)NOT NULL,
Nit Numeric(20)NOT NULL,
Prec_uni Numeric(20) NOT NULL,
Prec_total Numeric(20)NOT NULL,
Puesto Varchar(40)NOT NULL,
Fecha Varchar(40)NOT NULL,
)


CREATE TABLE Cotizacion(
NoCot Varchar(50)Primary Key,
NomProve Varchar(50)NOT NULL,
TelCot Numeric(10)NOT NULL,
DireCot Varchar(50)NOT NULL,
CantCot Varchar(50)NOT NULL,
ProdCot Varchar(50)NOT NULL,
PreCot Numeric(20) NOT NULL,
FechaCot Varchar(50)NOT NULL,
)

SELECT * from usuarios


insert into usuarios( usuario,contrase�a,nombre,apellido,Puesto, sexo) values ('admin', '123', 'Carlos', 'Donis', 'Administrador','M')